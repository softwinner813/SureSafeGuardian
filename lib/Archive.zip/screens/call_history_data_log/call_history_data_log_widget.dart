
import 'package:guardian/data/model/mqtt/mqtt_event.dart';
import 'package:guardian/data/mqtt/MqttUtils.dart';
import 'package:guardian/data/repository.dart';
import 'package:guardian/screens/components/LoadingView.dart';
import 'package:guardian/screens/components/UserInfoWayView.dart';
import 'package:guardian/screens/drawer/Drawer.dart';

import '../components/app_bar_component_widget.dart';
import '../components/bottom_nav_component_widget.dart';
import '../flutter_flow/flutter_flow_theme.dart';
import '../flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';


class CallHistoryDataLogWidget extends StatefulWidget {
  CallHistoryDataLogWidget({Key? key}) : super(key: key);

  @override
  _CallHistoryDataLogWidgetState createState() =>
      _CallHistoryDataLogWidgetState();
}

class _CallHistoryDataLogWidgetState extends State<CallHistoryDataLogWidget> {
  final scaffoldKey = GlobalKey<ScaffoldState>();
  int activeTabIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      endDrawer: DrawerScreen(),
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Stack(
          children: [
            Image.asset(
              'assets/images/Group_933.png',
              width: double.infinity,
              height: double.infinity,
              fit: BoxFit.cover,
            ),
            Column(
              children: [
                AppBarComponentWidget(),
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(16, 8, 16, 0),
                  child: UserInfoAwayView(),
                ),
                Expanded(
                  child: Padding(
                    padding: EdgeInsetsDirectional.fromSTEB(16, 0, 16, 0),
                    child: ListView(
                      padding: EdgeInsets.zero,
                      scrollDirection: Axis.vertical,
                      children: [
                        Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(0, 32, 0, 0),
                          child: Column(
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              Row(
                                mainAxisSize: MainAxisSize.max,
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  InkWell(
                                    onTap: (){
                                      setState(() {
                                        activeTabIndex = 0;
                                      });
                                    },
                                    child: Container(
                                      width: 148,
                                      height: 50,
                                      decoration: BoxDecoration(
                                        color: activeTabIndex == 0 ? Color(0xFF9A3CDC) : Color(0xFFD8B0F2),
                                        borderRadius: BorderRadius.circular(20),
                                      ),
                                      child: Column(
                                        mainAxisSize: MainAxisSize.max,
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          Padding(
                                            padding:
                                                EdgeInsetsDirectional.fromSTEB(
                                                    16, 0, 16, 0),
                                            child: Text(
                                              'Call History',
                                              style: TextStyle(
                                                color: Colors.white,
                                                fontSize: 18,
                                              ),
                                            ),
                                          )
                                        ],
                                      ),
                                    ),
                                  ),
                                  InkWell(
                                    onTap: (){
                                      setState(() {
                                        activeTabIndex = 1;
                                      });
                                    },
                                    child: Container(
                                      width: 168,
                                      height: 50,
                                      decoration: BoxDecoration(
                                        color: activeTabIndex == 1 ? Color(0xFF9A3CDC) : Color(0xFFD8B0F2),
                                        borderRadius: BorderRadius.circular(20),
                                      ),
                                      child: Column(
                                        mainAxisSize: MainAxisSize.max,
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          Padding(
                                            padding:
                                                EdgeInsetsDirectional.fromSTEB(
                                                    16, 0, 16, 0),
                                            child: Text(
                                              'Home Temperature',
                                              style: TextStyle(
                                                color: Colors.white,
                                                fontSize: 14,
                                              ),
                                            ),
                                          )
                                        ],
                                      ),
                                    ),
                                  )
                                ],
                              ),
                              Padding(
                                padding:
                                    EdgeInsetsDirectional.fromSTEB(0, 24, 0, 0),
                                child: Row(
                                  mainAxisSize: MainAxisSize.max,
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    InkWell(
                                      onTap: (){
                                        setState(() {
                                          activeTabIndex = 2;
                                        });
                                      },
                                      child: Container(
                                        width: 148,
                                        height: 50,
                                        decoration: BoxDecoration(
                                          color: activeTabIndex == 2 ? Color(0xFF9A3CDC) : Color(0xFFD8B0F2),
                                          borderRadius: BorderRadius.circular(20),
                                        ),
                                        child: Column(
                                          mainAxisSize: MainAxisSize.max,
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: [
                                            Padding(
                                              padding:
                                                  EdgeInsetsDirectional.fromSTEB(
                                                      16, 0, 16, 0),
                                              child: Text(
                                                'I\'m Ok Check',
                                                style: TextStyle(
                                                  color: Colors.white,
                                                  fontSize: 18,
                                                ),
                                              ),
                                            )
                                          ],
                                        ),
                                      ),
                                    ),
                                    InkWell(
                                      onTap: (){
                                        setState(() {
                                          activeTabIndex = 3;
                                        });
                                      },
                                      child: Container(
                                        width: 168,
                                        height: 50,
                                        decoration: BoxDecoration(
                                          color: activeTabIndex == 3 ? Color(0xFF9A3CDC) : Color(0xFFD8B0F2),
                                          borderRadius: BorderRadius.circular(20),
                                        ),
                                        child: Column(
                                          mainAxisSize: MainAxisSize.max,
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: [
                                            Padding(
                                              padding:
                                                  EdgeInsetsDirectional.fromSTEB(
                                                      16, 0, 16, 0),
                                              child: Text(
                                                'Activity Alert',
                                                style: TextStyle(
                                                  color: Colors.white,
                                                  fontSize: 18,
                                                ),
                                              ),
                                            )
                                          ],
                                        ),
                                      ),
                                    )
                                  ],
                                ),
                              )
                            ],
                          ),
                        ),
                        Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(0, 32, 0, 0),
                          child: Row(
                            mainAxisSize: MainAxisSize.max,
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              Text(
                                'Date',
                                style: TextStyle(
                                  color: FlutterFlowTheme.primaryColor,
                                ),
                              ),
                              Text(
                                'Time',
                                style: TextStyle(
                                  color: FlutterFlowTheme.primaryColor,
                                ),
                              ),
                              Text(
                                'Status',
                                style: TextStyle(
                                  color: FlutterFlowTheme.primaryColor,
                                ),
                              )
                            ],
                          ),
                        ),
                        if(activeTabIndex == 0 )Expanded(
                          child: FutureBuilder<List<MqttEvent>?>(
                            future: Repository().getAllAlarmCall(context), // async work
                            builder: (BuildContext context, AsyncSnapshot<List<MqttEvent>?> snapshot) {
                              switch (snapshot.connectionState) {
                                case ConnectionState.waiting: return LoadingView();
                                default:
                                  if (snapshot.hasError)
                                    return Container();
                                  else
                                    return ListView.builder(
                                      shrinkWrap: true,
                                        itemCount: snapshot.data?.length,
                                        physics: AlwaysScrollableScrollPhysics(),
                                        itemBuilder: (context,index){
                                        MqttEvent? event = snapshot.data?[index];
                                      return Padding(
                                        padding: EdgeInsetsDirectional.fromSTEB(0, 8, 0, 0),
                                        child: Row(
                                          mainAxisSize: MainAxisSize.max,
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          children: [
                                            Text(
                                              '${MqttUtils().dateTimeToFormat(event?.dateCreated)}',
                                              style: TextStyle(
                                                color: FlutterFlowTheme.primaryColor,
                                              ),
                                            ),
                                            Text(
                                              '${MqttUtils().dateTimeToTimeFormat(event?.dateCreated)}',
                                              style: TextStyle(
                                                color: FlutterFlowTheme.primaryColor,
                                              ),
                                            ),
                                            Text(
                                              '',
                                              style: TextStyle(
                                                color: FlutterFlowTheme.primaryColor,
                                              ),
                                            ),
                                            Container(
                                              width: 100,
                                              height: 30,
                                              decoration: BoxDecoration(
                                                color: Color(0xFFD1D16A),
                                                borderRadius: BorderRadius.circular(20),
                                              ),
                                              child: Column(
                                                mainAxisSize: MainAxisSize.max,
                                                mainAxisAlignment: MainAxisAlignment.center,
                                                children: [
                                                  Text(
                                                    'Call ${event?.status??""}',
                                                    style: TextStyle(
                                                      color: Colors.white,
                                                    ),
                                                  )
                                                ],
                                              ),
                                            )
                                          ],
                                        ),
                                      );
                                    });
                              }
                            },
                          ),
                        ),
                        if(activeTabIndex == 1 ) Expanded(
                          child: FutureBuilder<List<MqttEvent>>(
                            future: Repository().getMqttTempList(context), // async work
                            builder: (BuildContext context, AsyncSnapshot<List<MqttEvent>> snapshot) {
                              switch (snapshot.connectionState) {
                                case ConnectionState.waiting: return LoadingView();
                                default:
                                  if (snapshot.hasError)
                                    return Container();
                                  else
                                    return ListView.builder(
                                        shrinkWrap: true,
                                        physics: AlwaysScrollableScrollPhysics(),
                                        itemCount: snapshot.data?.length,
                                        itemBuilder: (context,index){
                                          MqttEvent? mqttEvent = snapshot.data?[index];
                                          return  Padding(
                                            padding:
                                            EdgeInsetsDirectional.fromSTEB(0, 16, 0, 0),
                                            child: Row(
                                              mainAxisSize: MainAxisSize.max,
                                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                              children: [
                                                Column(
                                                  mainAxisSize: MainAxisSize.max,
                                                  children: [
                                                    Text(
                                                      '${MqttUtils().dateTimeToFormat(mqttEvent?.dateCreated)}',
                                                      style: TextStyle(
                                                        color: FlutterFlowTheme.primaryColor,
                                                      ),
                                                    )
                                                  ],
                                                ),
                                                Column(
                                                  mainAxisSize: MainAxisSize.max,
                                                  children: [
                                                    Text(
                                                      '${MqttUtils().dateTimeToTimeFormat(mqttEvent?.dateCreated)}',
                                                      style: TextStyle(
                                                        color: FlutterFlowTheme.primaryColor,
                                                      ),
                                                    )
                                                  ],
                                                ),
                                                Column(
                                                  mainAxisSize: MainAxisSize.max,
                                                  children: [
                                                    Text(
                                                      '${mqttEvent?.temperature??"--"}°c',
                                                      style: TextStyle(
                                                        color: FlutterFlowTheme.primaryColor,
                                                      ),
                                                    )
                                                  ],
                                                ),
                                                Column(
                                                  mainAxisSize: MainAxisSize.max,
                                                  children: [
                                                    Image.asset(
                                                      mqttEvent?.status == "normal" ? 'assets/images/Group_943.png' : 'assets/images/Group_942.png' ,
                                                      width: 12,
                                                      height: 12,
                                                      fit: BoxFit.cover,
                                                    )
                                                  ],
                                                )
                                              ],
                                            ),
                                          );
                                        });
                              }
                            },
                          ),
                        ),
                        if(activeTabIndex == 3)  Expanded(
                          child: FutureBuilder<List<MqttEvent>>(
                            future: Repository().getMqttPirList(context), // async work
                            builder: (BuildContext context, AsyncSnapshot<List<MqttEvent>> snapshot) {
                              switch (snapshot.connectionState) {
                                case ConnectionState.waiting: return LoadingView();
                                default:
                                  if (snapshot.hasError)
                                    return Container();
                                  else
                                    return ListView.builder(
                                        shrinkWrap: true,
                                        physics: AlwaysScrollableScrollPhysics(),
                                        itemCount: snapshot.data?.length,
                                        itemBuilder: (context,index){
                                          MqttEvent? mqttEvent = snapshot.data?[index];
                                          return Padding(
                                            padding: EdgeInsetsDirectional.fromSTEB(0, 16, 0, 0),
                                            child: Row(
                                              mainAxisSize: MainAxisSize.max,
                                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                              children: [
                                                Column(
                                                  mainAxisSize: MainAxisSize.max,
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: [
                                                    Text(
                                                      '${MqttUtils().dateTimeToFormat(mqttEvent?.dateCreated)}',
                                                      style: TextStyle(
                                                        color: FlutterFlowTheme.primaryColor,
                                                      ),
                                                    )
                                                  ],
                                                ),
                                                Column(
                                                  mainAxisSize: MainAxisSize.max,
                                                  children: [
                                                    Text(
                                                      '${MqttUtils().dateTimeToTimeFormat(mqttEvent?.dateCreated)}',
                                                      style: TextStyle(
                                                        color: FlutterFlowTheme.primaryColor,
                                                      ),
                                                    )
                                                  ],
                                                ),
                                                Column(
                                                  mainAxisSize: MainAxisSize.max,
                                                  children: [
                                                    Image.asset(
                                                      (mqttEvent?.event == "iamlife" || mqttEvent?.status == "1") ?  'assets/images/Group_943.png' : 'assets/images/Group_942.png' ,
                                                      width: 12,
                                                      height: 12,
                                                      fit: BoxFit.cover,
                                                    )
                                                  ],
                                                )
                                              ],
                                            ),
                                          );
                                        });
                              }
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                //BottomNavComponentWidget()
              ],
            )
          ],
        ),
      ),
    );
  }
  Widget rowData(){
    return Column(
      children: [
        Padding(
          padding: EdgeInsetsDirectional.fromSTEB(0, 8, 0, 0),
          child: Container(
            width: 100,
            height: 1,
            decoration: BoxDecoration(
              color: Color(0x80000000),
            ),
          ),
        ),
        Padding(
          padding: EdgeInsetsDirectional.fromSTEB(0, 8, 0, 0),
          child: Row(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                '21/10/20',
                style: TextStyle(
                  color: FlutterFlowTheme.primaryColor,
                ),
              ),
              Text(
                '13:52pm',
                style: TextStyle(
                  color: FlutterFlowTheme.primaryColor,
                ),
              ),
              Text(
                '03:22',
                style: TextStyle(
                  color: FlutterFlowTheme.primaryColor,
                ),
              ),
              Text(
                'Angela',
                style: TextStyle(
                  color: FlutterFlowTheme.primaryColor,
                ),
              ),
              Container(
                width: 100,
                height: 30,
                decoration: BoxDecoration(
                  color: Color(0xFFD1D16A),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      'Call Active',
                      style: TextStyle(
                        color: Colors.white,
                      ),
                    )
                  ],
                ),
              )
            ],
          ),
        ),
        Padding(
          padding: EdgeInsetsDirectional.fromSTEB(0, 24, 0, 0),
          child: Row(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Text(
                    '21/10/20',
                    style: TextStyle(
                      color: FlutterFlowTheme.primaryColor,
                    ),
                  )
                ],
              ),
              Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Text(
                    '13:52pm',
                    style: TextStyle(
                      color: FlutterFlowTheme.primaryColor,
                    ),
                  )
                ],
              ),
              Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Text(
                    '03:22',
                    style: TextStyle(
                      color: FlutterFlowTheme.primaryColor,
                    ),
                  )
                ],
              ),
              Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Text(
                    'Angela',
                    style: TextStyle(
                      color: FlutterFlowTheme.primaryColor,
                    ),
                  )
                ],
              ),
              Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Image.asset(
                    'assets/images/Group_942.png',
                    width: 12,
                    height: 12,
                    fit: BoxFit.cover,
                  )
                ],
              ),
              Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Container(
                    width: 60,
                    height: 20,
                    decoration: BoxDecoration(
                      color: Color(0xFF2540C6),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment:
                      MainAxisAlignment.center,
                      children: [
                        Text(
                          'Export to Email',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 8,
                          ),
                        )
                      ],
                    ),
                  )
                ],
              ),
              Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Container(
                    width: 60,
                    height: 20,
                    decoration: BoxDecoration(
                      color: Color(0xFF2540C6),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment:
                      MainAxisAlignment.center,
                      children: [
                        Text(
                          'Open Dialed Log',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 8,
                          ),
                        )
                      ],
                    ),
                  )
                ],
              )
            ],
          ),
        ),
        Padding(
          padding: EdgeInsetsDirectional.fromSTEB(0, 24, 0, 0),
          child: Row(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Text(
                    '21/10/20',
                    style: TextStyle(
                      color: FlutterFlowTheme.primaryColor,
                    ),
                  )
                ],
              ),
              Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Text(
                    '13:52pm',
                    style: TextStyle(
                      color: FlutterFlowTheme.primaryColor,
                    ),
                  )
                ],
              ),
              Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Text(
                    '03:22',
                    style: TextStyle(
                      color: FlutterFlowTheme.primaryColor,
                    ),
                  )
                ],
              ),
              Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Text(
                    'Angela',
                    style: TextStyle(
                      color: FlutterFlowTheme.primaryColor,
                    ),
                  )
                ],
              ),
              Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Image.asset(
                    'assets/images/Group_943.png',
                    width: 12,
                    height: 12,
                    fit: BoxFit.cover,
                  )
                ],
              ),
              Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Container(
                    width: 60,
                    height: 20,
                    decoration: BoxDecoration(
                      color: Color(0xFF2540C6),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment:
                      MainAxisAlignment.center,
                      children: [
                        Text(
                          'Export to Email',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 8,
                          ),
                        )
                      ],
                    ),
                  )
                ],
              ),
              Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Container(
                    width: 60,
                    height: 20,
                    decoration: BoxDecoration(
                      color: Color(0xFF2540C6),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment:
                      MainAxisAlignment.center,
                      children: [
                        Text(
                          'Open Dialed Log',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 8,
                          ),
                        )
                      ],
                    ),
                  )
                ],
              )
            ],
          ),
        ),
        Padding(
          padding: EdgeInsetsDirectional.fromSTEB(0, 24, 0, 0),
          child: Row(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Text(
                    '21/10/20',
                    style: TextStyle(
                      color: FlutterFlowTheme.primaryColor,
                    ),
                  )
                ],
              ),
              Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Text(
                    '13:52pm',
                    style: TextStyle(
                      color: FlutterFlowTheme.primaryColor,
                    ),
                  )
                ],
              ),
              Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Text(
                    '03:22',
                    style: TextStyle(
                      color: FlutterFlowTheme.primaryColor,
                    ),
                  )
                ],
              ),
              Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Text(
                    'Angela',
                    style: TextStyle(
                      color: FlutterFlowTheme.primaryColor,
                    ),
                  )
                ],
              ),
              Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Image.asset(
                    'assets/images/Group_943.png',
                    width: 12,
                    height: 12,
                    fit: BoxFit.cover,
                  )
                ],
              ),
              Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Container(
                    width: 60,
                    height: 20,
                    decoration: BoxDecoration(
                      color: Color(0xFF2540C6),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment:
                      MainAxisAlignment.center,
                      children: [
                        Text(
                          'Export to Email',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 8,
                          ),
                        )
                      ],
                    ),
                  )
                ],
              ),
              Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Container(
                    width: 60,
                    height: 20,
                    decoration: BoxDecoration(
                      color: Color(0xFF2540C6),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment:
                      MainAxisAlignment.center,
                      children: [
                        Text(
                          'Open Dialed Log',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 8,
                          ),
                        )
                      ],
                    ),
                  )
                ],
              )
            ],
          ),
        ),
        Padding(
          padding: EdgeInsetsDirectional.fromSTEB(0, 24, 0, 0),
          child: Row(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Text(
                    '21/10/20',
                    style: TextStyle(
                      color: FlutterFlowTheme.primaryColor,
                    ),
                  )
                ],
              ),
              Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Text(
                    '13:52pm',
                    style: TextStyle(
                      color: FlutterFlowTheme.primaryColor,
                    ),
                  )
                ],
              ),
              Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Text(
                    '03:22',
                    style: TextStyle(
                      color: FlutterFlowTheme.primaryColor,
                    ),
                  )
                ],
              ),
              Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Text(
                    'Angela',
                    style: TextStyle(
                      color: FlutterFlowTheme.primaryColor,
                    ),
                  )
                ],
              ),
              Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Image.asset(
                    'assets/images/Group_943.png',
                    width: 12,
                    height: 12,
                    fit: BoxFit.cover,
                  )
                ],
              ),
              Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Container(
                    width: 60,
                    height: 20,
                    decoration: BoxDecoration(
                      color: Color(0xFF2540C6),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment:
                      MainAxisAlignment.center,
                      children: [
                        Text(
                          'Export to Email',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 8,
                          ),
                        )
                      ],
                    ),
                  )
                ],
              ),
              Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Container(
                    width: 60,
                    height: 20,
                    decoration: BoxDecoration(
                      color: Color(0xFF2540C6),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment:
                      MainAxisAlignment.center,
                      children: [
                        Text(
                          'Open Dialed Log',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 8,
                          ),
                        )
                      ],
                    ),
                  )
                ],
              )
            ],
          ),
        ),
        Padding(
          padding: EdgeInsetsDirectional.fromSTEB(0, 24, 0, 0),
          child: Row(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Text(
                    '21/10/20',
                    style: TextStyle(
                      color: FlutterFlowTheme.primaryColor,
                    ),
                  )
                ],
              ),
              Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Text(
                    '13:52pm',
                    style: TextStyle(
                      color: FlutterFlowTheme.primaryColor,
                    ),
                  )
                ],
              ),
              Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Text(
                    '03:22',
                    style: TextStyle(
                      color: FlutterFlowTheme.primaryColor,
                    ),
                  )
                ],
              ),
              Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Text(
                    'Angela',
                    style: TextStyle(
                      color: FlutterFlowTheme.primaryColor,
                    ),
                  )
                ],
              ),
              Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Image.asset(
                    'assets/images/Group_943.png',
                    width: 12,
                    height: 12,
                    fit: BoxFit.cover,
                  )
                ],
              ),
              Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Container(
                    width: 60,
                    height: 20,
                    decoration: BoxDecoration(
                      color: Color(0xFF2540C6),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment:
                      MainAxisAlignment.center,
                      children: [
                        Text(
                          'Export to Email',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 8,
                          ),
                        )
                      ],
                    ),
                  )
                ],
              ),
              Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Container(
                    width: 60,
                    height: 20,
                    decoration: BoxDecoration(
                      color: Color(0xFF2540C6),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment:
                      MainAxisAlignment.center,
                      children: [
                        Text(
                          'Open Dialed Log',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 8,
                          ),
                        )
                      ],
                    ),
                  )
                ],
              )
            ],
          ),
        )
      ],
    );
  }
}
